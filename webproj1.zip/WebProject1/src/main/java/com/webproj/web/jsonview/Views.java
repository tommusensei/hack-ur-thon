package com.webproj.web.jsonview;

public class Views {
    public static class Public {}
}
